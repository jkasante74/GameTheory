package ecosystem;

import sim.engine.*;
import sim.app.virus.VirusInfectionDemo;
import sim.display.*;
import sim.portrayal.continuous.ContinuousPortrayal2D;
import sim.portrayal.grid.*;

import java.awt.*;

import javax.swing.*;

import sim.portrayal.simple.OvalPortrayal2D;
import sim.portrayal.simple.RectanglePortrayal2D;

public class ModelWithGUI extends GUIState {
	public Display2D display;
	public JFrame displayFrame;
	
	// SparseGridPortrayal2D rabbitPortrayal = new SparseGridPortrayal2D(); useful for SparseGrid
	// SparseGridPortrayal2D grassPortrayal = new SparseGridPortrayal2D();
	
	ContinuousPortrayal2D rabbitPortrayal = new ContinuousPortrayal2D();
	ContinuousPortrayal2D grassPortrayal = new ContinuousPortrayal2D();
	ContinuousPortrayal2D weedsPortrayal = new ContinuousPortrayal2D();
	
	
	/**
	 * This is the method which starts the the moment the program is compiled
	 * @param args
	 */
	public static void main(String[] args) {
		ModelWithGUI ex = new ModelWithGUI();
		Console c = new Console(ex);
		c.setVisible(true); // Activate this if you want to show  the console
	//	c.pressPlay();      // Activate this if you want to hide the console
		
		System.out.println("Start Simulation");
	}

	/**
	 * Calls the super class and links the simulation environment with the Graphical User Interface
	 * in terms of time.
	 */
	public ModelWithGUI() {
		super(new Model(System.currentTimeMillis()));
	}

	/**
	 * This method is called when the quit button is clicked on the console
	 */
	public void quit() {
		super.quit(); 

		if (displayFrame!=null) displayFrame.dispose();
		displayFrame = null;
		display = null;
	}

	/**
	 * This method is called when the start method is clicked on the console
	 * 
	 */
	
	public void start() {
		super.start();
		setupPortrayals();
	}
	
	/**
	 * This method displays the name of the control window
	 * @return displayTitle for the GUI window
	 */
	public static String getName(){
		String displayTitle = "Rabbits and Grass Simulation";
		return displayTitle;
	}
	
	
	/**
	 * Once the start method is clicked this method is called automatically
	 * and then it loads the portrayal
	 */
	public void load(SimState state) {
		super.load(state);
		setupPortrayals();
	}
	
	
	/**
	 * This method does all the work by connecting the GUI class with the model class
	 * and sets the shape, color and display after each step
	 */
	public void setupPortrayals() {
        Model se = (Model)state;
        
		//rabbitPortrayal.setField(se.rabbitSpace);

        rabbitPortrayal.setField(((Model)state).rabbitSpace);
		
       OvalPortrayal2D r = new OvalPortrayal2D(Color.blue);
       rabbitPortrayal.setPortrayalForClass(Rabbits.class , r);
	
     	
		
		//reschedule the displayer
		display.reset();
		
		//redraw the display
		display.repaint();
	}
	
	/**
	 * Override the step method in GUIState and pop a message when the threshold has been reached 
	 */
	public boolean step() {
		boolean result = super.step();
		Model se = (Model)super.state;
		if(se.errMsg != null) {
			System.out.println("Model says:" + se.errMsg);
			JOptionPane.showMessageDialog(displayFrame, se.errMsg);
			se.errMsg = null;
		}
		return result;
	}

	/**
	 * Creates the frame size of the display, makes it visible, 
	 * sets the background color and attach the portrayal 
	 * 
	 */
	
	public void init(Controller c){
		super.init(c);
		display = new Display2D(400,400,this);
		displayFrame = display.createFrame();
		displayFrame.setTitle(getName());	//This set the title for the simulation frame which i have set to be the same as the control window
		c.registerFrame(displayFrame);
		displayFrame.setVisible(true);
		display.setBackdrop(Color.white);
		display.attach(rabbitPortrayal,"Rabbits");

	}

	/**
	 * Inspects simulation objects and return the state
	 */
	public Object getSimulationInspectedObject() {
		return state;
	}
}

