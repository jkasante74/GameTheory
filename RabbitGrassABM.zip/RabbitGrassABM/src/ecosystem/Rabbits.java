package ecosystem;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

import sim.engine.*;
import sim.portrayal.DrawInfo2D;
import sim.util.Bag;
import sim.util.Double2D;
import sim.util.Int2D;
public class Rabbits implements Steppable{			//This allows MASON to run all the agents defined in this class

	/**
	 * Declaring global variables
	 */
	private static final long serialVersionUID = 1L;
	public double y ;
	public double x ;
	public Stoppable event;
	public double xdir;
	public double ydir;
	public Int2D loc;
	boolean avoidCollisions = true;
	boolean boundaries = true;
	boolean randomWalk = true;
	public int randomSteps = 0;
	public int pauseTime = 0;
	public int n = 1;
	public Int2D[] randomMovement = null;
	public volatile int popCount = 1;
	public int counter = 1;
	public volatile Bag myAgents = new Bag();
	public double total;
	public boolean reprod = true;
	private volatile boolean waiting = false;
	
	/**
	 * This constructor takes the state of the environment and randomly create a 
	 * direction and destination point for agent to head towards
	 * @param xdir
	 * @param ydir
	 */
	 public Rabbits(SimState state){
    	Model se =(Model)state;
    	x = se.random.nextInt(se.gridWidth);
		y = se.random.nextInt(se.gridHeight);
    	xdir = se.random.nextInt(2)-1;
    	ydir = se.random.nextInt(2)-1;
     }
    
   /**
    * Informs the rabbit agent about the state of the environment
    * whether its toroidal or bounded 
    * @param x
    */
    public void setboundaries(boolean x){
		boundaries = x;
	}

	
    
	/**
	 * The step method controls the movement pattern of the agents based on user selection,
	 * Monitor the feeding pattern of the agents 
	 * Calls the reproduce method based on the population requirement
	 * All rabbit agents implement this method 
	 * @param state
	 */

	@Override
	public void step(SimState state) {
		Model se = (Model)state;
	    final double reproduceLimit = se.reproduceLevel;
	 
		
	// Selecting the agents movement pattern	
		
	    if(se.mobilityMod == "Random Waypoint")
			   randomWaypoint(state);
	    
	    else if(se.mobilityMod == "Random Walk") 
			randomWalk(state);
		
	   
				
	    else if(se.mobilityMod == "Random Direction")
		   randomDirection(state);
	   
	   else if(se.mobilityMod == "Modified Random Direction")
		   modifiedRandomDirection(state);
		
	   
	   
	  //check rabbit's neighborhood for grass based on distance (1.5)
	   Object obj = null;
	   Bag nearby = se.rabbitSpace.getNeighborsWithinDistance(new Double2D(x, y), se.rabbitObserveDistance);
	  
	   
		obj =  nearby.objs[0];
	   
	//Are we close to something we can feed on?	
	   if (obj.getClass() == Grass.class){  // check if object within distance is a grass
           
		   	   // Takes the location of the grass object
			   Double2D location =  se.rabbitSpace.getObjectLocation(nearby.objs[0]);
		   	 			   
			   setXY(location.x, location.y); // Move to the location of the grass or weed
			   
			   //Delete the object at that location (Grass Dies)
			   se.rabbitSpace.removeObjectsAtLocation(location);
			
			  //calculate the total energy received (for this Rabbit)
			   this.total += se.energy; // Increase the total energy after every grass eaten
			   System.out.println("Total Energy increased : " + this.total);
			   System.out.println("-----------------------");
			}
	   if(obj.getClass() == Weeds.class){
		
		    	// Takes the location of the grass object
		   		Double2D location =  se.rabbitSpace.getObjectLocation(nearby.objs[0]);
		   		 setXY(location.x, location.y); // Move to the location of the grass or weed
		   
		   		 //Delete the object at that location (Grass Dies)
		   		 se.rabbitSpace.removeObjectsAtLocation(location);
				 this.total -= se.energy; // Increase the total energy after every grass eaten
				 System.out.println("Total Energy reduced to : " + this.total);
				 System.out.println("-----------------------");
	   }
                
	 
		  //Let's deduct some energy amount for leaving
	   		if(se.movementCost){
	   		this.total -= se.moveCost;
	   		System.out.println("Movement Cost : " + se.moveCost + " and total energy is now "+this.total);
	   		}
	   
	   //Reproduce when the total energy becomes equal or greater than the reproduction level
	    if(this.total >= reproduceLimit){
			 
			   System.out.println("Before Energy = " + this.total);
			   if(reproduce(se))
				   this.total-=reproduceLimit;
			   System.out.println("After Energy = " + this.total);
			   		   
		   }
	   	
		   else{     
	   		   System.out.println("Insufficient Energy");
	       }
	  
		
	}
	

	/**
	 * This method reproduces an agent by checking if the reproducing agent has the required reproduction
	 * Energy and the population threshold has not been reached
	 * @param se
	 * @return 
	 */
	
		public boolean reproduce(Model se){
			Bag b = null;
			Int2D newLoc = null;	
			do {
				newLoc = newLocation(se);	//Randomly choose a location within the environment
				b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newLoc.x, newLoc.y)); //get agent at that location
			} while (b != null); 
				if(se.hasSpaceForNewRabbit()) { //Do we have room for one more agent?
					Rabbits r = new Rabbits(se); // create a new rabbit agent
						se.rabbitSpace.setObjectLocation(r, new Double2D(newLoc.x, newLoc.y)); //place agent at location
						se.addRabit(r);	//add agent to the number of rabbits in environment
						System.out.println("Rabbit is reproduced!!"); 
						return true;
					
				}				
				else{
					System.out.println("Poppulation Threshold reached ......"); //Notify about population threshold
					
				}
				
			return false;
		}
		
		/**
		 * This method considers the environment size and 
		 * randomly creates a location for an agent to be placed 
		 * @param se
		 * @return Int2D
		 */
		public Int2D newLocation(final Model se){
			int x,y;
			
				final int gridWidth = se.gridWidth;
				final int gridHeight = se.gridHeight;
				x = se.random.nextInt(gridWidth - 1) + 1; 
				y = se.random.nextInt(gridHeight - 1) + 1; 
			
			return new Int2D(x,y);
		}
	
		
	/**
	 * Set the x and y destination cordinates for an agent
	 * @param x
	 * @param y
	 */
	 public void setXY(double x, double y){
			this.x = x;
			this.y = y;
		}

	 /**
	  * Determine the direction agent should use
	  * @param xdir
	  * @param ydir
	  */
		public void setXYdir(int xdir, int ydir){
			this.xdir = xdir;
			this.ydir = ydir;
		}
	
		/**Receive the boolean value of whether Rabbits should 
		 * collide or not from the Simulation Environment
		 * @param x
		 */
		public void setavoidCollisions(boolean x){
			avoidCollisions = x;
		}
		
		/**
		 * Agent die
		 * 
		 */
		public void die(Model se, Double2D rabbitLoc){
			se.rabbitSpace.removeObjectsAtLocation(rabbitLoc);
			System.out.println(" is dead...");
			}
	

		

		/**
		 * This method describes the random Walk mobility model which agents randomly choose a 
		 * speed and direction and moves in that direction for a specified number of steps and 
		 * and then recycle the process
		 * @param state
		 */
		public void randomWalk(SimState state){
			Model se = (Model)state;
			boolean toroidal = se.toroidal;
		
			
			// Let's take the number of steps based on the number generated
		//	for(int i = 1; i <= n; i++){
			//convert the SimState to our Environment
			double newx = x + xdir; //generate the coordinates of the
			double newy = y + ydir; //new location to move to
			
			//check if there is boundary
			if(!toroidal){
			newx = bx(state,newx);
			newy = by(state,newy);
			}
			
			
		//	Bag b = se.rabbitSpace.getObjectsAtLocation(newx, newy);  Useful for SparseGrid
			Bag b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newx, newy));
			
			//get the bag at that location
		//	if((b != null && b.numObjs > 0)||((randomSteps % se.stepsInterval) == 0)){  //the bag could be null
			if(((this.randomSteps % se.stepsInterval) == 0)){  //the bag could be null
			//if not, find out if it is empty or has another Rabbits in it or the time interval has elapsed.
			
		   xdir = se.random.nextInt(3)-1; //change direction randomly
		   ydir = se.random.nextInt(3)-1;
		   n = randInt(1,10);
			}
		
			x += xdir ; //set the new direction
			y += ydir;
			
			if(!toroidal){
				x = bxdir(state,x);
				y = bydir(state,y);
			}
			
			else{
				x = se.rabbitSpace.stx(x); //use the system toroidal property
			    y = se.rabbitSpace.sty(y);  //use the system toroidal property

			}
			//	se.rabbitSpace.setObjectLocation(this, x, y);
			se.rabbitSpace.setObjectLocation(this, new Double2D((x), (y)));
		   //	System.out.println("Simulation : "+se.simtime+ " x : " + x + "\t y :" + y + "\t Discretization : " + n);
			
			randomSteps++;
		//	}
			se.simtime++;
			
		}
			
		
		
		/**
		 * This method describes the randomWaypoint mobility model
		 * @param state
		 */
		
		public void randomWaypoint (SimState state) {
			
			if(waiting) return;
			
			Model se = (Model)state;
			boolean toroidal = se.toroidal;
		
		// Let's take the number of steps(speed) based on the number generated
	     //  for(int i = 1; i <= n; i++){
				
			//convert the SimState to our Environment
			double newx = x + xdir; //generate the coordinates of the
			double newy = y + ydir; //new location to move to
			
			//check if there is boundary
			if(!toroidal){
			newx = bx(state,newx);
			newy = by(state,newy);
			}
		
	  //	Bag b = se.rabbitSpace.getObjectsAtLocation(newx, newy); useful in sparseField
			Bag b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newx, newy)); //get the bag object at that location and store as in b
			
		//  If there is an object there or the chosen steps has been reached, pause for a random time.
		//	if((b != null && b.numObjs > 0)||((randomSteps % se.stepsInterval) == 0)){  //the bag could be null
			if((this.randomSteps % se.stepsInterval) == 0){
							
				pauseTime = randInt(1000,5000);
				holdingObjects(pauseTime, state);
				
				//if not, find out if it is empty or has another Rabbits in it or the time interval has elapsed.
			      xdir = se.random.nextInt(3)-1; //change direction randomly
			      ydir = se.random.nextInt(3)-1;
			     
			      n = randInt(1,10);	//randomly choose speed
			}
			      
						
				x += xdir; //set the new direction
				y += ydir;
				if(!toroidal){
					x = bxdir(state,x);
					y = bydir(state,y);
				}
				
				else{
					x = se.rabbitSpace.stx(x); //use the system toroidal property
				    y = se.rabbitSpace.sty(y);  //use the system toroidal property

				}
			
			// Let's set the object in that location
			
		//	se.rabbitSpace.setObjectLocation(this, x, y); //used when using sparseField
			se.rabbitSpace.setObjectLocation(this, new Double2D(x, y));
			
			 this.randomSteps++;	  
		//	}
			se.simtime++;
		}
		
		
		
		
		/**
		 * This method describes the randomDirection mobility model
		 * At the boundary the agent pauses for a randomly determined time and then
		 * reflect of the boundary at an angle determined based on the direction
		 * @param state
		 */
		
		public void randomDirection (SimState state) {
			if(waiting) return;
			
			Model se = (Model)state;
			
		// Let's take the number of steps(speed) based on the number generated
		//    for(int i = 1; i <= n; i++){
			double newx = x + xdir;  //generate the coordinates of the
			double newy = y + ydir;  //new location to move to
			newx = bx(state,newx);
			newy = by(state,newy);
		
		//	Bag b = se.rabbitSpace.getObjectsAtLocation(newx, newy);
			Bag b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newx, newy));
			
			//get the bag at that location
		//	if((b != null && b.numObjs > 0)||(this.x == (se.gridWidth - 1))||(this.x == (0))||(this.y == (0))||(this.y == (se.gridHeight - 1))){  //the bag could be null
			
			if((this.x == (se.gridWidth))||(this.x == (0))||(this.y == (0))||(this.y == (se.gridHeight))){  
				pauseTime = randInt(1000,5000);
				holdingObjects(pauseTime, state);
				
				  xdir = se.random.nextInt(3)-1; //change direction randomly
			      ydir = se.random.nextInt(3)-1;
			      
			      n = randInt(1,10);	//randomly choose speed
			}
			
			x += xdir; //set the new direction
			y += ydir;
			x = bxdir(state,x);
			y = bydir(state,y);
			
			
		//	se.rabbitSpace.setObjectLocation(this, x, y);
			se.rabbitSpace.setObjectLocation(this, new Double2D(x, y));
		//    }
			
			   
		}
		
		
		
		
		/**
		 * This method describes the modified Random Direction mobility model
		 * which is a modification to the Random Direction such that here
		 * an agent chooses a direction and speed randomly but also
		 * chooses a location midway and pauses for a randomly determined time and then
		 * change direction randomly.
		 * @param state
		 */
		
		public void modifiedRandomDirection (SimState state) {
			if(waiting) return;
			
			Model se = (Model)state;
			
			// Let's take the number of steps(speed) based on the number generated
		//       for(int i = 1; i <= n; i++){
		   //convert the SimState to our Environment
			double newx = x + xdir; //generate the coordinates of the
			double newy = y + ydir; //new location to move to
			newx = bx(state,newx);
			newy = by(state,newy);
			int prevx = randInt((int) x, se.gridWidth); //randomly generate a point on the x-axis
			int prevy = randInt((int) y, se.gridHeight); //randomly generate a point on the y-axis
		//	Bag b = se.rabbitSpace.getObjectsAtLocation(newx, newy);
			Bag b = se.rabbitSpace.getObjectsAtLocation(new Double2D(newx, newy));
			
			//get the bag at that location
			if((x == (se.gridWidth - prevx))||(x == (se.gridWidth - 1))||(x == (0))||(y == (0))||(y == (se.gridHeight - 1))
					||(x == (0 + prevx))||(y == (0 + prevy))||(y == (se.gridHeight - prevy))){  //the bag could be null
			
				
				pauseTime = randInt(1000,5000);
				holdingObjects(pauseTime, state);
				
				  xdir = se.random.nextInt(3)-1; //randomly generate x direction
			      ydir = se.random.nextInt(3)-1; // randomly generate y direction
			      
			      n = randInt(1,10);	//randomly choose speed
			}
			x += xdir; //set the new directions
			y += ydir;
			x = bxdir(state,x); //change the direction
			y = bydir(state,y);
	//		se.rabbitSpace.setObjectLocation(this, x, y); this is for SparseGrid
			se.rabbitSpace.setObjectLocation(this, new Double2D(x, y));
		//       }
			 System.out.println("Random Direction : Pause times : " + pauseTime);
			   
			
		
		}
		
		
	
		
		
		/**
		* Causes a change in the direction of the objects / agents
		*
		*/
		protected double bx(SimState state, double x){
			Model se = (Model)state;
			//convert the SimState to our Model
			if(x<0 || x>= se.gridWidth) {
				return x-xdir; //change the direction of x
			}
			else {
				return x;
			}
		}

		/**Determine which direction it 
		 * should bounce off to in the x axis
		 * @param state
		 * @param x
		 * @return
		 */
		protected double bxdir(SimState state, double x){
			Model se = (Model)state;
			//convert the SimState to our Environment
			if(x<0 || x>= se.gridWidth) {
				xdir = -xdir;
				return x+xdir;
			}
			else {
				return x;
			}
		}

		/**Have we reached the boundary on the y-axis?
		 * 
		 * @param state
		 * @param y
		 * @return
		 */
		protected double by(SimState state, double y){
			Model se = (Model)state;
			
			//convert the SimState to our Environment
			if(y<0 || y>= se.gridHeight) {
				return  y - ydir;
			}
			else {
				return y;
			}

		}

		
		/**Determine which direction it 
		 * should bounce off to in the x axis
		 */
		protected double bydir(SimState state, double y){
			Model se = (Model)state;
			//convert the SimState to our Environment
			if(y<0 || y>= se.gridHeight) {
				ydir = -ydir;
				return y + ydir;
			}
			else {
				return y;
			}
		}
	
	/**
	 * This method randomly chooses a pause/wait time between 1 second and 5 seconds for the agent to wait
	 * in the random waypoint, random direction and modified waypoint mobility model
	 * 
	 */
		public static int randInt(int min, int max) {

		    // NOTE: Usually this should be a field rather than a method
		    // variable so that it is not re-seeded every call.
		    Random rand = new Random();

		    // nextInt is normally exclusive of the top value,
		    // so add 1 to make it inclusive
		    int randomNum = rand.nextInt((max - min) + 1) + min;

		    return randomNum;
		}
		
	
		
		/**
		 * This method holds the object for a specified number 
		 * @param pauseTime
		 * @param x
		 * @param y
		 * @param state
		 */
		 void holdingObjects(final int pauseTime,  SimState state){
			 
			 waiting = true;
			 new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						System.out.println("Paused for : " + pauseTime);
						System.out.println("Thread id : " + Thread.currentThread().getId());
						Thread.sleep(pauseTime);
					} catch (InterruptedException e) { }
					waiting = false;
				}
			 }).start();
			 Model se = (Model)state;
			 //se.errMsg += this.hashCode() + " Waiting for: " + pauseTime + "\n";
			
			
		}
		 

			
}

